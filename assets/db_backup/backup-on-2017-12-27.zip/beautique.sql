#
# TABLE STRUCTURE FOR: company_info
#

DROP TABLE IF EXISTS `company_info`;

CREATE TABLE `company_info` (
  `company_id` int(11) NOT NULL AUTO_INCREMENT,
  `company_name` varchar(50) NOT NULL,
  `company_logo` varchar(200) NOT NULL,
  `company_country` varchar(50) NOT NULL,
  `company_address` text NOT NULL,
  `company_gstin` varchar(20) NOT NULL,
  `company_pan` varchar(50) NOT NULL,
  `company_fax` varchar(50) NOT NULL,
  `company_phone` bigint(20) NOT NULL,
  `company_careno` bigint(20) NOT NULL,
  `company_landline` bigint(20) NOT NULL,
  `company_website` varchar(50) NOT NULL,
  `company_email` varchar(50) NOT NULL,
  `company_pin` varchar(10) NOT NULL,
  `company_state` varchar(50) NOT NULL,
  `company_status` int(11) NOT NULL,
  PRIMARY KEY (`company_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `company_info` (`company_id`, `company_name`, `company_logo`, `company_country`, `company_address`, `company_gstin`, `company_pan`, `company_fax`, `company_phone`, `company_careno`, `company_landline`, `company_website`, `company_email`, `company_pin`, `company_state`, `company_status`) VALUES ('1', 'Wahylab', '23_-01.jpg', 'india', 'dxfdfgfdg', 'sdfdsfd3454645645', '7894561230123', '0482168952', '9048048024', '54123678920', '4735261162', 'www.wahylab.com', 'wahy@gmail.com', '689676', 'kerala', '1');


#
# TABLE STRUCTURE FOR: customerdetails
#

DROP TABLE IF EXISTS `customerdetails`;

CREATE TABLE `customerdetails` (
  `customer_id` int(11) NOT NULL AUTO_INCREMENT,
  `customer_name` varchar(50) NOT NULL,
  `customer_address` text NOT NULL,
  `customer_phone` bigint(20) NOT NULL,
  `customer_email` varchar(20) NOT NULL,
  `customer_status` int(11) NOT NULL,
  PRIMARY KEY (`customer_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `customerdetails` (`customer_id`, `customer_name`, `customer_address`, `customer_phone`, `customer_email`, `customer_status`) VALUES ('1', 'Jobymon', 'ffdgdfg', '9784512603', 'joby@gmail.com', '1');


#
# TABLE STRUCTURE FOR: financial_year
#

DROP TABLE IF EXISTS `financial_year`;

CREATE TABLE `financial_year` (
  `fin_year_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `fin_startdate` date NOT NULL,
  `fin_enddate` date NOT NULL,
  `modifiedby` varchar(50) NOT NULL,
  `fin_status` int(11) NOT NULL,
  PRIMARY KEY (`fin_year_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `financial_year` (`fin_year_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `modifiedby`, `fin_status`) VALUES ('1', '2016-2017', '2017-12-01', '2017-12-31', '1', '1');


#
# TABLE STRUCTURE FOR: newaccount
#

DROP TABLE IF EXISTS `newaccount`;

CREATE TABLE `newaccount` (
  `account_id` int(11) NOT NULL AUTO_INCREMENT,
  `account_name` varchar(50) NOT NULL,
  `account_description` text NOT NULL,
  `account_status` int(11) NOT NULL,
  PRIMARY KEY (`account_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `newaccount` (`account_id`, `account_name`, `account_description`, `account_status`) VALUES ('1', 'qwerty', 'zxczxcxzc', '1');


#
# TABLE STRUCTURE FOR: sale_details
#

DROP TABLE IF EXISTS `sale_details`;

CREATE TABLE `sale_details` (
  `sale_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_id_fk` int(11) NOT NULL,
  `service_invoice` int(11) NOT NULL,
  `service_name` varchar(20) NOT NULL,
  `customer_id` int(11) NOT NULL,
  `sale_date` date NOT NULL,
  `service_rate` double NOT NULL,
  `service_discount` double NOT NULL,
  `service_tax` varchar(20) NOT NULL,
  `service_nettotal` double NOT NULL,
  `service_grandtotal` double NOT NULL,
  `service_status` int(11) NOT NULL,
  PRIMARY KEY (`sale_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `sale_details` (`sale_id`, `service_id_fk`, `service_invoice`, `service_name`, `customer_id`, `sale_date`, `service_rate`, `service_discount`, `service_tax`, `service_nettotal`, `service_grandtotal`, `service_status`) VALUES ('1', '1', '100', 'massage', '1', '2017-12-23', '520', '0', '1', '525.2', '2045.2', '1');
INSERT INTO `sale_details` (`sale_id`, `service_id_fk`, `service_invoice`, `service_name`, `customer_id`, `sale_date`, `service_rate`, `service_discount`, `service_tax`, `service_nettotal`, `service_grandtotal`, `service_status`) VALUES ('2', '2', '100', 'Wesdf', '1', '2017-12-23', '500', '0', '0', '500', '2045.2', '1');
INSERT INTO `sale_details` (`sale_id`, `service_id_fk`, `service_invoice`, `service_name`, `customer_id`, `sale_date`, `service_rate`, `service_discount`, `service_tax`, `service_nettotal`, `service_grandtotal`, `service_status`) VALUES ('3', '3', '100', 'ere', '1', '2017-12-23', '1000', '0', '2', '1020', '2045.2', '1');


#
# TABLE STRUCTURE FOR: service_details
#

DROP TABLE IF EXISTS `service_details`;

CREATE TABLE `service_details` (
  `service_id` int(11) NOT NULL AUTO_INCREMENT,
  `service_unique_id` text NOT NULL,
  `service_name` varchar(50) NOT NULL,
  `service_hsn` varchar(50) NOT NULL,
  `service_rate` double NOT NULL,
  `servicetax` int(11) NOT NULL,
  `service_status` int(11) NOT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `service_details` (`service_id`, `service_unique_id`, `service_name`, `service_hsn`, `service_rate`, `servicetax`, `service_status`) VALUES ('1', '100', 'massage', 'qwert520', '520', '1', '1');
INSERT INTO `service_details` (`service_id`, `service_unique_id`, `service_name`, `service_hsn`, `service_rate`, `servicetax`, `service_status`) VALUES ('2', '101', 'Wesdf', 'sdsad45456', '500', '0', '1');
INSERT INTO `service_details` (`service_id`, `service_unique_id`, `service_name`, `service_hsn`, `service_rate`, `servicetax`, `service_status`) VALUES ('3', '102', 'ere', 'dsfd45', '1000', '2', '1');


#
# TABLE STRUCTURE FOR: tax_class
#

DROP TABLE IF EXISTS `tax_class`;

CREATE TABLE `tax_class` (
  `tax_id` int(11) NOT NULL AUTO_INCREMENT,
  `tax_name` varchar(255) NOT NULL,
  `tax_type` int(11) NOT NULL,
  `tax_amount` double NOT NULL,
  `tax_description` text NOT NULL,
  `tax_status` int(11) NOT NULL,
  PRIMARY KEY (`tax_id`)
) ENGINE=InnoDB AUTO_INCREMENT=14 DEFAULT CHARSET=latin1;

INSERT INTO `tax_class` (`tax_id`, `tax_name`, `tax_type`, `tax_amount`, `tax_description`, `tax_status`) VALUES ('1', 'GST @ 12% (split tax)', '1', '12', 'Nill', '1');
INSERT INTO `tax_class` (`tax_id`, `tax_name`, `tax_type`, `tax_amount`, `tax_description`, `tax_status`) VALUES ('2', 'GST @ 18% (split tax)', '1', '18', 'Nill', '1');
INSERT INTO `tax_class` (`tax_id`, `tax_name`, `tax_type`, `tax_amount`, `tax_description`, `tax_status`) VALUES ('3', 'GST @ 28% (split tax)', '1', '28', 'Nill', '1');
INSERT INTO `tax_class` (`tax_id`, `tax_name`, `tax_type`, `tax_amount`, `tax_description`, `tax_status`) VALUES ('4', 'GST @ 5% (split tax)', '1', '5', 'Nill', '1');
INSERT INTO `tax_class` (`tax_id`, `tax_name`, `tax_type`, `tax_amount`, `tax_description`, `tax_status`) VALUES ('5', 'GST @ Nill', '1', '0', 'Nill', '1');
INSERT INTO `tax_class` (`tax_id`, `tax_name`, `tax_type`, `tax_amount`, `tax_description`, `tax_status`) VALUES ('6', 'GST @ Zero', '1', '0', 'Nill', '1');
INSERT INTO `tax_class` (`tax_id`, `tax_name`, `tax_type`, `tax_amount`, `tax_description`, `tax_status`) VALUES ('7', 'VAT @ 5%', '1', '5', 'Nill', '1');
INSERT INTO `tax_class` (`tax_id`, `tax_name`, `tax_type`, `tax_amount`, `tax_description`, `tax_status`) VALUES ('8', 'IGST @ 12%', '2', '12', 'Nill', '1');
INSERT INTO `tax_class` (`tax_id`, `tax_name`, `tax_type`, `tax_amount`, `tax_description`, `tax_status`) VALUES ('9', 'IGST @ 18%', '2', '18', 'Nill', '1');
INSERT INTO `tax_class` (`tax_id`, `tax_name`, `tax_type`, `tax_amount`, `tax_description`, `tax_status`) VALUES ('10', 'IGST @ 28%', '2', '28', 'Nill', '1');
INSERT INTO `tax_class` (`tax_id`, `tax_name`, `tax_type`, `tax_amount`, `tax_description`, `tax_status`) VALUES ('11', 'IGST @ 5%', '2', '5', 'Nill', '1');
INSERT INTO `tax_class` (`tax_id`, `tax_name`, `tax_type`, `tax_amount`, `tax_description`, `tax_status`) VALUES ('12', 'IGST @ Nill', '2', '0', 'Nill', '1');
INSERT INTO `tax_class` (`tax_id`, `tax_name`, `tax_type`, `tax_amount`, `tax_description`, `tax_status`) VALUES ('13', 'IGST @ Zero', '2', '0', 'Nill', '1');


#
# TABLE STRUCTURE FOR: taxslab
#

DROP TABLE IF EXISTS `taxslab`;

CREATE TABLE `taxslab` (
  `taxslab_id` int(11) NOT NULL AUTO_INCREMENT,
  `finyear_id_fk` int(11) NOT NULL,
  `taxslab_amount` double NOT NULL,
  `taxslab_description` text NOT NULL,
  `taxslab_status` int(11) NOT NULL,
  `modifiedby` varchar(50) NOT NULL,
  PRIMARY KEY (`taxslab_id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `taxslab` (`taxslab_id`, `finyear_id_fk`, `taxslab_amount`, `taxslab_description`, `taxslab_status`, `modifiedby`) VALUES ('1', '1', '0', 'xcvcxv fdgfghhfghfgh', '1', '1');
INSERT INTO `taxslab` (`taxslab_id`, `finyear_id_fk`, `taxslab_amount`, `taxslab_description`, `taxslab_status`, `modifiedby`) VALUES ('2', '1', '5', 'xfdfds erretryrtyrty', '1', '1');
INSERT INTO `taxslab` (`taxslab_id`, `finyear_id_fk`, `taxslab_amount`, `taxslab_description`, `taxslab_status`, `modifiedby`) VALUES ('3', '1', '12', '', '1', '1');
INSERT INTO `taxslab` (`taxslab_id`, `finyear_id_fk`, `taxslab_amount`, `taxslab_description`, `taxslab_status`, `modifiedby`) VALUES ('4', '1', '18', '', '1', '1');
INSERT INTO `taxslab` (`taxslab_id`, `finyear_id_fk`, `taxslab_amount`, `taxslab_description`, `taxslab_status`, `modifiedby`) VALUES ('5', '1', '28', '', '1', '1');


#
# TABLE STRUCTURE FOR: user_details
#

DROP TABLE IF EXISTS `user_details`;

CREATE TABLE `user_details` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `user_type` varchar(5) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=6 DEFAULT CHARSET=latin1;

INSERT INTO `user_details` (`id`, `user_name`, `email`, `password`, `user_type`, `created_date`, `updated_date`, `status`) VALUES ('1', 'admin', 'admin@gmail.com', 'admin@321', 'A', '2017-12-01 12:42:44', '2017-12-21 12:28:22', '1');
INSERT INTO `user_details` (`id`, `user_name`, `email`, `password`, `user_type`, `created_date`, `updated_date`, `status`) VALUES ('2', 'joby', 'jobymon99@gmail.com', 'joby@321', 'A', '2017-12-21 09:10:21', '2017-12-21 09:10:21', '1');
INSERT INTO `user_details` (`id`, `user_name`, `email`, `password`, `user_type`, `created_date`, `updated_date`, `status`) VALUES ('3', 'praveen', 'praveen123@gmail.com', 'praveen@321', 'S', '2017-12-21 09:12:34', '2017-12-21 09:32:53', '1');
INSERT INTO `user_details` (`id`, `user_name`, `email`, `password`, `user_type`, `created_date`, `updated_date`, `status`) VALUES ('4', 'vishnu', 'Vishnu@gmail.com', 'vishnu@321', 'S', '2017-12-23 08:08:33', '2017-12-23 08:08:33', '1');
INSERT INTO `user_details` (`id`, `user_name`, `email`, `password`, `user_type`, `created_date`, `updated_date`, `status`) VALUES ('5', 'ajith', 'ajith@gmail.com', 'ajith@321', 'S', '2017-12-23 08:09:09', '2017-12-23 08:09:09', '1');


#
# TABLE STRUCTURE FOR: voucher_details
#

DROP TABLE IF EXISTS `voucher_details`;

CREATE TABLE `voucher_details` (
  `voucher_id` int(11) NOT NULL AUTO_INCREMENT,
  `vouch_id` int(11) NOT NULL,
  `account_head` varchar(50) NOT NULL,
  `amount` double NOT NULL,
  `narration` text NOT NULL,
  `created_date` date NOT NULL,
  `isactive` int(11) NOT NULL,
  `fin_year` varchar(50) NOT NULL,
  `user_id` int(11) NOT NULL,
  `type` varchar(50) NOT NULL,
  `voucher_status` int(11) NOT NULL,
  PRIMARY KEY (`voucher_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `voucher_details` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('1', '100', 'Current Bill', '0', 'bbvbv', '2017-12-20', '1', '2016-2017', '1', 'voucher', '1');
INSERT INTO `voucher_details` (`voucher_id`, `vouch_id`, `account_head`, `amount`, `narration`, `created_date`, `isactive`, `fin_year`, `user_id`, `type`, `voucher_status`) VALUES ('2', '101', 'Electricity', '0', 'payed to KSEB', '2017-12-22', '1', '2016-2017', '1', 'voucher', '1');


#
# TABLE STRUCTURE FOR: voucher_entry
#

DROP TABLE IF EXISTS `voucher_entry`;

CREATE TABLE `voucher_entry` (
  `entry_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `entry_date` date NOT NULL,
  `user_id` int(11) NOT NULL,
  `voucher_head` int(11) NOT NULL,
  `voucherid` int(11) NOT NULL,
  `entry_amount` double NOT NULL,
  `paidto` varchar(50) NOT NULL,
  `entry_narration` text NOT NULL,
  `entry_status` int(11) NOT NULL,
  PRIMARY KEY (`entry_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `voucher_entry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('1', '2016-2017', '2017-12-06', '1', '1', '100', '500', 'Raju', 'chgfhfg', '1');
INSERT INTO `voucher_entry` (`entry_id`, `fin_year`, `entry_date`, `user_id`, `voucher_head`, `voucherid`, `entry_amount`, `paidto`, `entry_narration`, `entry_status`) VALUES ('2', '2016-2017', '2017-12-13', '3', '2', '101', '150', 'kseb', 'cxv', '1');


