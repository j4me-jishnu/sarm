#
# TABLE STRUCTURE FOR: tbl_board
#

DROP TABLE IF EXISTS `tbl_board`;

CREATE TABLE `tbl_board` (
  `board_id` int(11) NOT NULL AUTO_INCREMENT,
  `state` varchar(50) NOT NULL,
  `district` varchar(50) NOT NULL,
  `location` varchar(255) NOT NULL,
  `roadname` varchar(255) NOT NULL,
  `medianame` varchar(255) NOT NULL,
  `timeperiod` varchar(50) NOT NULL,
  `board_height` varchar(50) NOT NULL,
  `board_width` varchar(50) NOT NULL,
  `rate` double NOT NULL,
  `quantity` varchar(255) NOT NULL,
  `mounting` varchar(255) NOT NULL,
  `printing` varchar(255) NOT NULL,
  `tax` varchar(255) NOT NULL,
  `total` varchar(255) NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`board_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_board` (`board_id`, `state`, `district`, `location`, `roadname`, `medianame`, `timeperiod`, `board_height`, `board_width`, `rate`, `quantity`, `mounting`, `printing`, `tax`, `total`, `status`) VALUES ('1', 'Kerala', 'Pathanamthitta', 'ranni', 'fgfdg', 'fdgfdg', '6', '60', '50', '800', '20', '52', '62', '18', '800', '1');


#
# TABLE STRUCTURE FOR: tbl_companyinfo
#

DROP TABLE IF EXISTS `tbl_companyinfo`;

CREATE TABLE `tbl_companyinfo` (
  `cmp_id` int(11) NOT NULL AUTO_INCREMENT,
  `cmp_name` varchar(50) NOT NULL,
  `cmp_phone` bigint(20) NOT NULL,
  `cmp_email` varchar(50) NOT NULL,
  `cmp_pan` varchar(50) NOT NULL,
  `cmp_gst` varchar(50) NOT NULL,
  `cmp_address` text NOT NULL,
  `owrner_name` varchar(20) NOT NULL,
  `owrner_phone` bigint(20) NOT NULL,
  `owrner_email` varchar(20) NOT NULL,
  `owrner_address` text NOT NULL,
  `owrner_gender` int(2) NOT NULL,
  `bank_name` varchar(50) NOT NULL,
  `acc_name` varchar(20) NOT NULL,
  `acc_number` bigint(20) NOT NULL,
  `acc_branch` varchar(50) NOT NULL,
  `acc_ifsc` varchar(20) NOT NULL,
  `cmp_status` int(11) NOT NULL,
  PRIMARY KEY (`cmp_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_companyinfo` (`cmp_id`, `cmp_name`, `cmp_phone`, `cmp_email`, `cmp_pan`, `cmp_gst`, `cmp_address`, `owrner_name`, `owrner_phone`, `owrner_email`, `owrner_address`, `owrner_gender`, `bank_name`, `acc_name`, `acc_number`, `acc_branch`, `acc_ifsc`, `cmp_status`) VALUES ('1', 'Aiswaria ooh media pvt.ltd', '4842803179', 'aiswariaooh@gmail.com', 'AAPCA3036N', '32AAPCA3036N1ZJ', '46/830 Vignesh Bhavan Savitha Road Vennala p.o Cochin Ernakulam', 'Aiswaria', '9846128822', 'aiswariaooh@gmail.co', ' 46/830 Vignesh Bhavan Savitha Road Vennala p.o Cochin Ernakulam           ', '1', 'Axis Bank', 'Aiswaria ooh media p', '7845129635421', 'Pathadipalam', 'UTBIB00045', '1');


#
# TABLE STRUCTURE FOR: tbl_customer
#

DROP TABLE IF EXISTS `tbl_customer`;

CREATE TABLE `tbl_customer` (
  `cust_id` int(11) NOT NULL AUTO_INCREMENT,
  `custname` varchar(50) NOT NULL,
  `custaddress` text NOT NULL,
  `custphone` bigint(20) NOT NULL,
  `custemail` varchar(50) NOT NULL,
  `custpan` varchar(100) NOT NULL,
  `custgst` varchar(100) NOT NULL,
  `custstatus` int(11) NOT NULL,
  PRIMARY KEY (`cust_id`)
) ENGINE=InnoDB AUTO_INCREMENT=4 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_customer` (`cust_id`, `custname`, `custaddress`, `custphone`, `custemail`, `custpan`, `custgst`, `custstatus`) VALUES ('1', 'Shawn Thomas', 'dfdsf', '9048048024', 'Shawnthomas@gmail.com', 'asd34fv23dfds3', 'dtretbfdsgfg', '1');
INSERT INTO `tbl_customer` (`cust_id`, `custname`, `custaddress`, `custphone`, `custemail`, `custpan`, `custgst`, `custstatus`) VALUES ('2', 'Joby Thomas', 'sdf', '7845129635', 'sdfsdfdsf', 'asd34fv23dfds3', 'dtretbfdsgfg', '1');
INSERT INTO `tbl_customer` (`cust_id`, `custname`, `custaddress`, `custphone`, `custemail`, `custpan`, `custgst`, `custstatus`) VALUES ('3', 'sdfsdf', '  sdfsdf', '7845129635', 'Shawnthomas@gmail.com', 'asd34fv23dfds3', 'dtretbfdsgfg', '1');


#
# TABLE STRUCTURE FOR: tbl_employee
#

DROP TABLE IF EXISTS `tbl_employee`;

CREATE TABLE `tbl_employee` (
  `empid` int(11) NOT NULL AUTO_INCREMENT,
  `empname` varchar(50) NOT NULL,
  `empaddress` text NOT NULL,
  `empemail` varchar(50) NOT NULL,
  `empphone` bigint(20) NOT NULL,
  `empdob` date NOT NULL,
  `empuid` varchar(100) NOT NULL,
  `empyid` varchar(50) NOT NULL,
  `gender` int(11) NOT NULL,
  `empstate` varchar(50) NOT NULL,
  `empcountry` varchar(50) NOT NULL,
  `empstatus` int(11) NOT NULL,
  PRIMARY KEY (`empid`)
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

#
# TABLE STRUCTURE FOR: tbl_enquiry
#

DROP TABLE IF EXISTS `tbl_enquiry`;

CREATE TABLE `tbl_enquiry` (
  `enqid` int(11) NOT NULL AUTO_INCREMENT,
  `custname` varchar(50) NOT NULL,
  `custaddress` text NOT NULL,
  `custemail` varchar(50) NOT NULL,
  `custphone` bigint(20) NOT NULL,
  `custplace` varchar(100) NOT NULL,
  `enqdetails` text NOT NULL,
  `enqstatus` int(11) NOT NULL,
  PRIMARY KEY (`enqid`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_enquiry` (`enqid`, `custname`, `custaddress`, `custemail`, `custphone`, `custplace`, `enqdetails`, `enqstatus`) VALUES ('1', 'sdfsdf', ' sdfsdfdsf   ', 'sdfsdfdsf', '9048048024', 'sdfsdf', 'sdfsdfsdf   ', '1');
INSERT INTO `tbl_enquiry` (`enqid`, `custname`, `custaddress`, `custemail`, `custphone`, `custplace`, `enqdetails`, `enqstatus`) VALUES ('2', 'Shemeer V a', 'Kollappaly Pala', 'shemeer@yahoo.com', '7845129635', 'Kollappally', ' vcvb', '1');


#
# TABLE STRUCTURE FOR: tbl_finyear
#

DROP TABLE IF EXISTS `tbl_finyear`;

CREATE TABLE `tbl_finyear` (
  `fin_year_id` int(11) NOT NULL AUTO_INCREMENT,
  `fin_year` varchar(50) NOT NULL,
  `fin_startdate` date NOT NULL,
  `fin_enddate` date NOT NULL,
  `modifiedby` varchar(50) NOT NULL,
  `fin_status` int(11) NOT NULL,
  PRIMARY KEY (`fin_year_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_finyear` (`fin_year_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `modifiedby`, `fin_status`) VALUES ('1', '2018-2019', '2018-04-12', '2018-04-27', '1', '0');
INSERT INTO `tbl_finyear` (`fin_year_id`, `fin_year`, `fin_startdate`, `fin_enddate`, `modifiedby`, `fin_status`) VALUES ('2', '2018-2020', '2018-04-27', '2018-04-21', '1', '1');


#
# TABLE STRUCTURE FOR: tbl_location
#

DROP TABLE IF EXISTS `tbl_location`;

CREATE TABLE `tbl_location` (
  `loc_id` int(11) NOT NULL AUTO_INCREMENT,
  `loc_name` varchar(50) NOT NULL,
  `loc_dis` varchar(50) NOT NULL,
  `loc_state` varchar(50) NOT NULL,
  `loc_desc` text NOT NULL,
  `loc_pic` text NOT NULL,
  `loc_status` int(11) NOT NULL,
  PRIMARY KEY (`loc_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_location` (`loc_id`, `loc_name`, `loc_dis`, `loc_state`, `loc_desc`, `loc_pic`, `loc_status`) VALUES ('1', 'Thiruvalla', 'Pathananamthitta', 'Kerala', 'sadfdgfd ghhgjhgj vbbjmhgjgh cghfthrtyrtuyuytdgxc vgd', 'kseb_bill.jpg', '1');


#
# TABLE STRUCTURE FOR: tbl_login
#

DROP TABLE IF EXISTS `tbl_login`;

CREATE TABLE `tbl_login` (
  `id` int(11) NOT NULL AUTO_INCREMENT,
  `user_name` varchar(50) NOT NULL,
  `email` varchar(50) NOT NULL,
  `password` varchar(50) NOT NULL,
  `user_type` varchar(5) NOT NULL,
  `created_date` datetime NOT NULL,
  `updated_date` datetime NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_login` (`id`, `user_name`, `email`, `password`, `user_type`, `created_date`, `updated_date`, `status`) VALUES ('1', 'admin', 'admin@gmail.com', 'admin@321', 'A', '2017-12-01 12:42:44', '2017-12-21 12:28:22', '1');


#
# TABLE STRUCTURE FOR: tbl_proposal
#

DROP TABLE IF EXISTS `tbl_proposal`;

CREATE TABLE `tbl_proposal` (
  `proposal_id` int(11) NOT NULL AUTO_INCREMENT,
  `custname` varchar(50) NOT NULL,
  `custaddress` text NOT NULL,
  `custemail` varchar(50) NOT NULL,
  `custphone` bigint(20) NOT NULL,
  `custdist` varchar(100) NOT NULL,
  `custtown` varchar(100) NOT NULL,
  `custloc` varchar(100) NOT NULL,
  `hordsize` varchar(100) NOT NULL,
  `hordtype` varchar(100) NOT NULL,
  `rate` double NOT NULL,
  `towards` varchar(100) NOT NULL,
  `period` varchar(100) NOT NULL,
  `flexcost` double NOT NULL,
  `mountcharge` double NOT NULL,
  `adtax` varchar(50) NOT NULL,
  `light_time` varchar(50) NOT NULL,
  `payterm` varchar(100) NOT NULL,
  `gst_tax` varchar(100) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `proposal_status` int(11) NOT NULL,
  PRIMARY KEY (`proposal_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_proposal` (`proposal_id`, `custname`, `custaddress`, `custemail`, `custphone`, `custdist`, `custtown`, `custloc`, `hordsize`, `hordtype`, `rate`, `towards`, `period`, `flexcost`, `mountcharge`, `adtax`, `light_time`, `payterm`, `gst_tax`, `file_name`, `proposal_status`) VALUES ('1', 'Joby Thomas', ' dsadsfdfdsf ', 'Jobythomas@gmail.com', '7845129635', 'Alleppey', 'Aroor', 'Aroor bridge', '25x26', 'Front lit', '15000', 'Towards Alleppey', '12 months', '56212', '1000', 'Included in the rate', '4 Hours starting from 7 PM', '50% advance along with work order and balance within 3 months', '18', '6Y9mi2018-06-06.pdf', '1');


#
# TABLE STRUCTURE FOR: tbl_quotation
#

DROP TABLE IF EXISTS `tbl_quotation`;

CREATE TABLE `tbl_quotation` (
  `quotation_id` int(11) NOT NULL AUTO_INCREMENT,
  `custid_fk` int(11) NOT NULL,
  `finyear` varchar(250) NOT NULL,
  `qtdate` date NOT NULL,
  `subject` text NOT NULL,
  `district` varchar(250) NOT NULL,
  `location` varchar(250) NOT NULL,
  `size` varchar(250) NOT NULL,
  `quantity` varchar(250) NOT NULL,
  `monthly_rate` double NOT NULL,
  `mounting_charge` double NOT NULL,
  `print_charge` double NOT NULL,
  `total_cost` double NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `quot_status` int(11) NOT NULL,
  PRIMARY KEY (`quotation_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_quotation` (`quotation_id`, `custid_fk`, `finyear`, `qtdate`, `subject`, `district`, `location`, `size`, `quantity`, `monthly_rate`, `mounting_charge`, `print_charge`, `total_cost`, `file_name`, `quot_status`) VALUES ('1', '1', '2018-2020', '2018-05-16', 'fghgfh', 'fghgfh', 'fghfghfg', '52x89', '20', '9250', '900', '7852', '7894521', 'ea0gu2018-05-23.pdf', '1');


#
# TABLE STRUCTURE FOR: tbl_release
#

DROP TABLE IF EXISTS `tbl_release`;

CREATE TABLE `tbl_release` (
  `release_id` int(11) NOT NULL AUTO_INCREMENT,
  `vendor_id_fk` int(11) NOT NULL,
  `tax_id_fk` int(11) NOT NULL,
  `hsn_sac` int(11) NOT NULL,
  `taxvalue` double NOT NULL,
  `invc` varchar(255) NOT NULL,
  `district` varchar(255) NOT NULL,
  `locations` varchar(255) NOT NULL,
  `height` varchar(255) NOT NULL,
  `width` varchar(255) NOT NULL,
  `area_insqft` varchar(255) NOT NULL,
  `fromdate` date NOT NULL,
  `todate` date NOT NULL,
  `finyear` varchar(255) NOT NULL,
  `type` varchar(255) NOT NULL,
  `rate_sqft` varchar(255) NOT NULL,
  `ratepermonth` varchar(255) NOT NULL,
  `file_name` varchar(255) NOT NULL,
  `invoice_st` int(11) NOT NULL,
  `invoice_file` varchar(255) NOT NULL,
  `release_status` int(11) NOT NULL,
  PRIMARY KEY (`release_id`)
) ENGINE=InnoDB AUTO_INCREMENT=23 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('1', '2', '1', '0', '5', 'UHuEt', 'aa', 'sdfdsf', '50', '50', '4512', '2018-05-30', '2018-05-31', '2018-2020', '4sdfsdf', 'sdfsdf', 'sdfdsf', 'UHuEt2018-05-25.pdf', '1', 'byjB32018-06-14.pdf', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('2', '2', '2', '0', '28', 'eHkGh', 'Kottayam', 'pampady', '50', '60', '300', '2018-06-30', '2018-06-27', '2018-2020', 'lit', '12.5', '4561', 'eHkGh2018-06-13.pdf', '1', '6L0bu2018-06-14.pdf', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('3', '2', '2', '0', '28', 'eHkGh', 'Pathanamthitta', 'Abanjn', '70', '80', '5600', '2018-06-27', '2018-06-30', '2018-2020', 'non-lit', '17', '5200', 'eHkGh2018-06-13.pdf', '1', '6L0bu2018-06-14.pdf', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('4', '2', '2', '451263', '18', 'Ybe7F', 'adsf', 'sdf', '40', '50', '200', '2018-06-29', '2018-07-07', '2018-2020', 'lit', '15.2', '451', 'Ybe7F2018-06-14.pdf', '0', '', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('5', '2', '1', '451263', '5', 'wXmVG', 'Kottayam', 'pampady', '40', '50', '200', '2018-06-16', '2018-06-26', '2018-2020', 'non-lit', '15.2', '451', 'wXmVG2018-06-14.pdf', '0', '', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('6', '2', '1', '451263', '5', 'wXmVG', 'Pathanamthitta', 'Kumbalam', '50', '80', '400', '2018-06-01', '2018-06-30', '2018-2020', 'lit', '15.2', '451', 'wXmVG2018-06-14.pdf', '0', '', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('7', '2', '2', '451263', '18', '2FRPk', 'Idukki', 'Kuttikkanam', '50', '50', '2500', '2018-06-21', '2018-06-30', '2018-2020', 'lit', '15.2', '451', '2FRPk2018-06-14.pdf', '0', '', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('8', '2', '2', '451263', '18', '2FRPk', 'Kollam', 'chinnakkada', '20', '20', '400', '2018-06-26', '2018-06-29', '2018-2020', 'non-lit', '15.2', '451', '2FRPk2018-06-14.pdf', '0', '', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('9', '2', '2', '451263', '18', 'DobWr', 'Idukki', 'Kuttikkanam', '50', '50', '2500', '2018-06-21', '2018-06-30', '2018-2020', 'lit', '15.2', '451', 'DobWr2018-06-14.pdf', '0', '', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('10', '2', '2', '451263', '18', 'DobWr', 'Kollam', 'chinnakkada', '20', '20', '400', '2018-06-26', '2018-06-29', '2018-2020', 'non-lit', '15.2', '451', 'DobWr2018-06-14.pdf', '0', '', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('11', '2', '2', '451263', '18', '5x0HI', 'Idukki', 'Kuttikkanam', '50', '50', '2500', '2018-06-21', '2018-06-30', '2018-2020', 'lit', '15.2', '451', '5x0HI2018-06-14.pdf', '0', '', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('12', '2', '2', '451263', '18', '5x0HI', 'Kollam', 'chinnakkada', '20', '20', '400', '2018-06-26', '2018-06-29', '2018-2020', 'non-lit', '15.2', '451', '5x0HI2018-06-14.pdf', '0', '', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('13', '2', '2', '451263', '18', 'kPAWV', 'Idukki', 'Kuttikkanam', '50', '50', '2500', '2018-06-21', '2018-06-30', '2018-2020', 'lit', '15.2', '451', 'kPAWV2018-06-14.pdf', '0', '', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('14', '2', '2', '451263', '18', 'kPAWV', 'Kollam', 'chinnakkada', '20', '20', '400', '2018-06-26', '2018-06-29', '2018-2020', 'non-lit', '15.2', '451', 'kPAWV2018-06-14.pdf', '0', '', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('15', '2', '2', '451263', '18', 'esAIz', 'Idukki', 'Kuttikkanam', '50', '50', '2500', '2018-06-21', '2018-06-30', '2018-2020', 'lit', '15.2', '451', 'esAIz2018-06-14.pdf', '0', '', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('16', '2', '2', '451263', '18', 'esAIz', 'Kollam', 'chinnakkada', '20', '20', '400', '2018-06-26', '2018-06-29', '2018-2020', 'non-lit', '15.2', '451', 'esAIz2018-06-14.pdf', '0', '', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('17', '2', '2', '451263', '18', 'GUcZO', 'Idukki', 'Kuttikkanam', '50', '50', '2500', '2018-06-21', '2018-06-30', '2018-2020', 'lit', '15.2', '451', 'GUcZO2018-06-14.pdf', '1', 'YkyIL2018-06-15.pdf', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('18', '2', '2', '451263', '18', 'GUcZO', 'Kollam', 'chinnakkada', '20', '20', '400', '2018-06-26', '2018-06-29', '2018-2020', 'non-lit', '15.2', '451', 'GUcZO2018-06-14.pdf', '1', 'YkyIL2018-06-15.pdf', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('19', '2', '2', '451263', '18', '0DlmM', 'Idukki', 'Kuttikkanam', '50', '50', '2500', '2018-06-21', '2018-06-30', '2018-2020', 'lit', '15.2', '451', '0DlmM2018-06-14.pdf', '0', '', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('20', '2', '2', '451263', '18', '0DlmM', 'Kollam', 'chinnakkada', '20', '20', '400', '2018-06-26', '2018-06-29', '2018-2020', 'non-lit', '15.2', '451', '0DlmM2018-06-14.pdf', '0', '', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('21', '2', '2', '451263', '18', 'lVGAu', 'Idukki', 'Kuttikkanam', '50', '50', '2500', '2018-06-21', '2018-06-30', '2018-2020', 'lit', '15.2', '451', 'lVGAu2018-06-14.pdf', '1', 'Io2KZ2018-06-14.pdf', '1');
INSERT INTO `tbl_release` (`release_id`, `vendor_id_fk`, `tax_id_fk`, `hsn_sac`, `taxvalue`, `invc`, `district`, `locations`, `height`, `width`, `area_insqft`, `fromdate`, `todate`, `finyear`, `type`, `rate_sqft`, `ratepermonth`, `file_name`, `invoice_st`, `invoice_file`, `release_status`) VALUES ('22', '2', '2', '451263', '18', 'lVGAu', 'Kollam', 'chinnakkada', '20', '20', '400', '2018-06-26', '2018-06-29', '2018-2020', 'non-lit', '15.2', '451', 'lVGAu2018-06-14.pdf', '1', 'Io2KZ2018-06-14.pdf', '1');


#
# TABLE STRUCTURE FOR: tbl_service
#

DROP TABLE IF EXISTS `tbl_service`;

CREATE TABLE `tbl_service` (
  `service_id` int(11) NOT NULL AUTO_INCREMENT,
  `finyear` varchar(50) NOT NULL,
  `invc` varchar(50) NOT NULL,
  `board_id_fk` int(11) NOT NULL,
  `board_name` varchar(50) NOT NULL,
  `board_height` varchar(50) NOT NULL,
  `board_width` varchar(50) NOT NULL,
  `brAmount` double NOT NULL,
  `FromDate` date NOT NULL,
  `ToDate` date NOT NULL,
  `status` int(11) NOT NULL,
  PRIMARY KEY (`service_id`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_service` (`service_id`, `finyear`, `invc`, `board_id_fk`, `board_name`, `board_height`, `board_width`, `brAmount`, `FromDate`, `ToDate`, `status`) VALUES ('1', '2018-2020', 'zESN0', '1', 'dfdsfdsfds', '52', '63', '900', '2018-06-26', '2018-06-28', '1');


#
# TABLE STRUCTURE FOR: tbl_taxdetails
#

DROP TABLE IF EXISTS `tbl_taxdetails`;

CREATE TABLE `tbl_taxdetails` (
  `tax_id` int(11) NOT NULL AUTO_INCREMENT,
  `taxname` varchar(50) NOT NULL,
  `taxamount` double NOT NULL,
  `taxdetails` text NOT NULL,
  `tax_status` int(11) NOT NULL,
  PRIMARY KEY (`tax_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_taxdetails` (`tax_id`, `taxname`, `taxamount`, `taxdetails`, `tax_status`) VALUES ('1', 'GST @ 5% (split tax)', '5', 'GST @ 5% (split tax) gst 5% split tax', '1');
INSERT INTO `tbl_taxdetails` (`tax_id`, `taxname`, `taxamount`, `taxdetails`, `tax_status`) VALUES ('2', 'GST @ 18% (split tax)', '18', 'GST @ 18% (split tax)  gst 18% split  tax', '1');


#
# TABLE STRUCTURE FOR: tbl_vendor
#

DROP TABLE IF EXISTS `tbl_vendor`;

CREATE TABLE `tbl_vendor` (
  `vendor_id` int(11) NOT NULL AUTO_INCREMENT,
  `vendorname` varchar(60) NOT NULL,
  `vendoraddress` text NOT NULL,
  `vendorphone` bigint(20) NOT NULL,
  `vendoremail` varchar(50) NOT NULL,
  `vendorstate` varchar(50) NOT NULL,
  `vendor_stcode` varchar(50) NOT NULL,
  `vendorgst` varchar(50) NOT NULL,
  `vendorpan` varchar(50) NOT NULL,
  `vendorstatus` int(11) NOT NULL,
  PRIMARY KEY (`vendor_id`)
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=latin1;

INSERT INTO `tbl_vendor` (`vendor_id`, `vendorname`, `vendoraddress`, `vendorphone`, `vendoremail`, `vendorstate`, `vendor_stcode`, `vendorgst`, `vendorpan`, `vendorstatus`) VALUES ('1', 'Shown Thomas', '   jkljklkjl ', '7845129632', 'sdfsdf', '', '', 'sdfdsf', 'sdfdsf', '1');
INSERT INTO `tbl_vendor` (`vendor_id`, `vendorname`, `vendoraddress`, `vendorphone`, `vendoremail`, `vendorstate`, `vendor_stcode`, `vendorgst`, `vendorpan`, `vendorstatus`) VALUES ('2', 'Shown Thomas', 'D7 Heavenly Plaza, Civil Line Road, Padamughal, Kakkanad, Kerala 682021', '9048048024', 'sdfsdf', 'Karnataka', '32', 'sdfdsf', 'posdnbc456yf45h', '1');


