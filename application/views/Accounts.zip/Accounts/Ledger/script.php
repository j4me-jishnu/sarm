<script>
	$(".ledgerhead").select2({
            placeholder: " -- Select supplier -- "
    });
    $('#ledger_date').datepicker({
      autoclose: true,
      format: 'dd/mm/yyyy'
      
	});
</script>